<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Demo ASIX</title>
</head>
<body>
    <h1>404 - No s'ha trobat la pàgina</h1>
    <p>La pàgina que busques no existeix</p>
</body>
</html>