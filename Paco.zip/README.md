# PHP
- Versió 1: Hello world i sintaxis bàsica
- Versió 2: MVC i Separation of Concerns
- Versió 3: MVC: Rutes i Database
