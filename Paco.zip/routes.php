<?php
//fitxer per definir les rutes
return [
    '/' => '../app/index.php',
    '/home' => '../app/index.php',
    '/index' => '../app/index.php',
    '/index.php' => '../app/index.php',
];